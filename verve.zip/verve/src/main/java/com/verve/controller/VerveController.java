package com.verve.controller;

import com.verve.service.HttpService;
import com.verve.service.RedisService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/verve")
public class VerveController {
    @Autowired
    private RedisService redisService;
    @Autowired
    private HttpService httpService;
    private final Logger logger = LoggerFactory.getLogger(VerveController.class);

    @GetMapping("/accept")
    public ResponseEntity<String> acceptRequest(@RequestParam int id, @RequestParam(required = false) String endpoint) {
        String key = "id_" + id;

        boolean isUnique = redisService.isUnique(key);

        if (isUnique) {
            redisService.addIdToSetWithExpiry(key);

            // Log unique count to external service
            logAndPushRequestCount();

            long uniqueRequestCount = redisService.getUniqueRequestCount();


            // Fire external HTTP request if endpoint is provided
            if (endpoint != null) {
                try {
                    httpService.sendHttpRequest(endpoint, uniqueRequestCount);
                    return ResponseEntity.ok("ok");
                } catch (Exception e) {
                    logger.error("Error calling external endpoint", e);
                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("failed");
                }
            } else {
                return ResponseEntity.ok("ok");
            }
        }

        return ResponseEntity.ok("ok");
    }

    private void logAndPushRequestCount() {
        long count = redisService.getUniqueRequestCount();
        logger.info("Unique requests in the last minute: {}", count);
    }
}
