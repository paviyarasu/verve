package com.verve;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VerveApplication {

	public static void main(String[] args) {
		SpringApplication.run(VerveApplication.class, args);
	}

}
