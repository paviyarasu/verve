package com.verve.service;

import org.springframework.stereotype.Service;
import org.springframework.data.redis.core.RedisTemplate;

import java.util.Set;
import java.util.concurrent.TimeUnit;

@Service
public class RedisService {
    private final RedisTemplate<String, String> redisTemplate;
    private static final String REDIS_SET_KEY = "unique_requests";

    public RedisService(RedisTemplate<String, String> redisTemplate) {
        this.redisTemplate = redisTemplate;
    }

    // Check if the ID is unique
    public boolean isUnique(String key) {
        return !redisTemplate.opsForSet().isMember(REDIS_SET_KEY, key);
    }

    // Add ID to Redis Set
    public void addIdToSetWithExpiry(String key) {
        redisTemplate.opsForSet().add(REDIS_SET_KEY, key);
        redisTemplate.expire(REDIS_SET_KEY, 60, TimeUnit.SECONDS);
    }

    public long getUniqueRequestCount() {
        return redisTemplate.opsForSet().size(REDIS_SET_KEY);
    }

}
