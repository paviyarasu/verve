package com.verve.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class HttpService {

    private final Logger logger = LoggerFactory.getLogger(HttpService.class);
    private final RestTemplate restTemplate = new RestTemplate();

    public void sendHttpRequest(String endpoint, long uniqueCount) throws Exception {
        String url = endpoint + "?unique_count=" + uniqueCount;
        HttpEntity<String> entity = new HttpEntity<>("");
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
        logger.info("HTTP request to {} returned status {}", url, response.getStatusCode());
    }
}