package com.verve;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VerveApplicationTests {

	@Test
	void contextLoads() {
	}

}
